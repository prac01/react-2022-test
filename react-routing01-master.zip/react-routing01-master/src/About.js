import React from 'react';
import './App.css';

function About() {
  return (
    <div>
        <h1>About Page</h1>
        <h2>What man? What!</h2>
    </div>
  );
}

export default About;
